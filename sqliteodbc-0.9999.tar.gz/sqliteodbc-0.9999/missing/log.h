#ifndef _LOG_H
#define _LOG_H

/*
 * Missing in most unixODBC installations but
 * needed by <odbcinstext.h>
 */

#endif
